<?php
/*
Template Name: Watchlist Page
*/
get_header();
?>

<div class="watchlist-page">
    <h1>Your Watchlist</h1>
    <div class="watchlist-grid" id="watchlistContainer">
        <!-- Movies from localStorage will populate here -->

    </div>
    <a href="/" class="go-home-link">Homepage</a>

</div>

<?php get_footer(); ?>