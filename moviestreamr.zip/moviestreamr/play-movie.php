<?php
/*
Template Name: Play Movie
*/

get_header();

$movie_id = isset($_GET['movie_id']) ? intval($_GET['movie_id']) : 0;
$movie = get_post($movie_id);
$video_file = get_field('full_movie', $movie_id);
$back_to_movie_url = get_permalink($movie->ID);

$video_url = '';
if ($video_file && isset($video_file['url'])) {
    $video_url = esc_url($video_file['url']);
}
?>

<div class="movie-player">
    <a href="<?php echo esc_url($back_to_movie_url); ?>" class="close-player-btn">✕</a>
    <h1 style="text-align: center;"><?php echo esc_html(get_the_title($movie_id)); ?></h1>


    <?php if ($video_url): ?>
        <video controls autoplay>
            <source src="<?php echo $video_url; ?>" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    <?php else: ?>
        <p style="color: white; text-align: center;">No full movie available.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>