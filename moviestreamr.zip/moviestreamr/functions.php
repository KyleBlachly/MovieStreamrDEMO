<?php

// Add theme support
add_theme_support('post-thumbnails');

// Enqueue styles
function moviestreamr_enqueue_assets()
{
  wp_enqueue_style('moviestreamr-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'moviestreamr_enqueue_assets');

// Register the "Movies" custom post type
function moviestreamr_register_movie_post_type()
{
  register_post_type('movie', array(
    'labels' => array(
      'name' => 'Movies',
      'singular_name' => 'Movie',
      'add_new_item' => 'Add New Movie',
      'edit_item' => 'Edit Movie',
      'new_item' => 'New Movie',
      'view_item' => 'View Movie',
      'search_items' => 'Search Movies',
      'not_found' => 'No movies found',
    ),
    'public' => true,
    'menu_icon' => 'dashicons-video-alt2',
    'has_archive' => true,
    'rewrite' => array('slug' => 'movies'),
    'supports' => array('title', 'editor', 'thumbnail'),
    'show_in_rest' => true
  ));
}
add_action('init', 'moviestreamr_register_movie_post_type');

function register_movie_taxonomies()
{
  register_taxonomy('genre', 'movie', array(
    'label' => 'Genres',
    'hierarchical' => false,
    'public' => true,
    'rewrite' => array('slug' => 'genre'),
    'show_admin_column' => true,
    'show_in_rest' => true, // So it's available in Gutenberg
  ));
}
add_action('init', 'register_movie_taxonomies');

function moviestreamr_enqueue_scripts()
{
  wp_enqueue_script(
    'moviestreamr-main-js',
    get_template_directory_uri() . '/main.js',
    array(), // dependencies, e.g. ['jquery']
    null,    // version
    true     // load in footer
  );
}
add_action('wp_enqueue_scripts', 'moviestreamr_enqueue_scripts');

function custom_play_movie_rewrite()
{
  add_rewrite_rule('^play-movie/?$', 'index.php?play_movie=1', 'top');
}
add_action('init', 'custom_play_movie_rewrite');

function custom_play_movie_query_vars($vars)
{
  $vars[] = 'play_movie';
  $vars[] = 'movie_id';
  return $vars;
}
add_filter('query_vars', 'custom_play_movie_query_vars');

function custom_play_movie_template($template)
{
  if (get_query_var('play_movie') == 1) {
    return get_template_directory() . '/play-movie.php';
  }
  return $template;
}
add_filter('template_include', 'custom_play_movie_template');
