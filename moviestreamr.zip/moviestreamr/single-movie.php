<?php get_header(); ?>

<?php
$rating = get_field('star_rating'); // e.g. 4.2
?>
<?php
$play_url = site_url('/play-movie') . '?movie_id=' . get_the_ID();
?>
<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
  <symbol id="star-shape" viewBox="0 0 24 24">
    <path d="M12 .587l3.668 7.431 8.2 1.192-5.934 5.782 
             1.4 8.172L12 18.896l-7.334 3.868 1.4-8.172
             L.132 9.21l8.2-1.192z" />
  </symbol>
</svg>

<section class="movie-hero" style="background-image: url('<?php the_field('main_image'); ?>');">
  <div class="overlay">
    <div class="movie-details">
      <h1><?php the_title(); ?></h1>
      <?php
      $terms = get_the_terms(get_the_ID(), 'genre');
      if ($terms && !is_wp_error($terms)) {
        $genre_names = wp_list_pluck($terms, 'name');
        echo '<p class="genre"><strong>Genre:</strong> ' . esc_html(implode(', ', $genre_names)) . '</p>';
      }
      ?>
      <p class="runtime"><strong>Runtime:</strong> <?php the_field('runtime'); ?></p>

      <div class="stars">
        <?php
        for ($i = 0; $i < 5; $i++) {
          $remaining = $rating - $i;
          $fillPercent = max(0, min(1, $remaining)); // clamp between 0 and 1
          $gradientId = 'starGrad' . $i;
        ?>
          <svg class="star" width="24" height="24">
            <defs>
              <linearGradient id="<?php echo $gradientId; ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="<?php echo ($fillPercent * 100); ?>%" stop-color="#FFFFFF" />
                <stop offset="<?php echo ($fillPercent * 100); ?>%" stop-color="#444" />
              </linearGradient>
            </defs>
            <use href="#star-shape" fill="url(#<?php echo $gradientId; ?>)" />
          </svg>
        <?php } ?>
        <span class="numeric-rating"><?php echo number_format($rating, 1); ?></span>
      </div>
    </div>
    <p class="bio"><?php the_content(); ?></p>
    <section class="movie-trailer">
      <div class="lowerBtns">
        <a href="<?php echo esc_url($play_url); ?>" class="play-full-button"><span class="play-icon">&#9658;</span> Play</a>
        <button class="launch-trailer">
          <span class="play-icon">&#9658;</span> Trailer
        </button>
        <?php $movie_id = get_the_ID(); ?>
        <button
          class="watchlist-toggle"
          data-movie-id="<?php echo $movie_id; ?>">
          + Watchlist
        </button>
      </div>

      <div class="trailer-overlay" id="trailerOverlay">
        <div class="overlay-content">
          <button class="close-trailer" id="closeTrailer">&times;</button>
          <video id="trailerVideo" controls preload="auto">
            <source src="<?php echo esc_url(get_field('clip')); ?>" type="video/mp4">
            Your browser does not support the video tag.
          </video>
        </div>
      </div>
    </section>
  </div>
  <section>
    <button class="go-watchlist" onclick="location.href='/watchlist'">Watchlist</button>
    <a href="/" class="go-home-link">Homepage</a>
  </section>
</section>



<?php get_footer(); ?>