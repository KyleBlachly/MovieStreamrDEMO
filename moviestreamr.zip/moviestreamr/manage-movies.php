<?php
/*
Template Name: Manage Movies
*/

get_header();
?>

<div class="manage-movies-page">
    <h1>Manage Movies</h1>

    <section class="add-movie-form">
        <h2>Add Movie</h2>
        <form id="addMovieForm" method="post" enctype="multipart/form-data">
            <label for="movie_title">Title:</label>
            <input type="text" name="movie_title" id="movie_title" required />

            <label for="thumbnail">Thumbnail:</label>
            <input type="file" name="thumbnail" id="thumbnail" accept="image/*" />

            <label for="main_image">Main Image:</label>
            <input type="file" name="main_image" id="main_image" accept="image/*" />

            <label for="description">Description:</label>
            <textarea name="description" id="description" rows="4"></textarea>

            <label for="runtime">Runtime:</label>
            <input type="number" name="runtime_hours" placeholder="Hours" min="0" />
            <input type="number" name="runtime_minutes" placeholder="Minutes" min="0" max="59" />

            <label for="star_rating">Star Rating (0.0 to 5.0):</label>
            <input type="number" name="star_rating" id="star_rating" min="0" max="5" step="0.1" required />

            <label for="genre">Genre:</label>
            <select name="genre" id="genre">
                <?php
                $genres = get_terms(['taxonomy' => 'genre', 'hide_empty' => false]);
                foreach ($genres as $genre) {
                    echo '<option value="' . esc_attr($genre->term_id) . '">' . esc_html($genre->name) . '</option>';
                }
                ?>
            </select>

            <label for="trailer">Trailer Clip:</label>
            <input type="file" name="trailer" id="trailer" accept="video/*" />

            <label for="full_movie">Full Movie:</label>
            <input type="file" name="full_movie" id="full_movie" accept="video/*" />

            <?php wp_nonce_field('add_movie_nonce', 'add_movie_nonce_field'); ?>
            <button type="submit" name="add_movie">Add Movie</button>
        </form>
    </section>

    <section class="remove-movie-form">
        <h2>Remove Movie</h2>
        <form id="removeMovieForm" method="post">
            <label for="delete_movie_id">Select Movie:</label>
            <select name="delete_movie_id" id="delete_movie_id">
                <?php
                $movies = get_posts(['post_type' => 'movie', 'posts_per_page' => -1]);
                foreach ($movies as $movie) {
                    echo '<option value="' . esc_attr($movie->ID) . '">' . esc_html($movie->post_title) . '</option>';
                }
                ?>
            </select>

            <?php wp_nonce_field('delete_movie_nonce', 'delete_movie_nonce_field'); ?>
            <button type="button" id="confirmDeleteBtn">Delete Selected Movie</button>
        </form>
    </section>

    <!-- Confirmation Modal -->
    <div id="deleteConfirmModal" class="modal hidden">
        <div class="modal-content">
            <p>Are you sure you want to delete <span id="movieToDelete"></span>?</p>
            <button id="deleteConfirm">Delete</button>
            <button id="cancelDelete">Cancel</button>
        </div>
    </div>
    <a href="/" class="back-home-btn">← Back to Home</a>
    <p>* This page is mostly frontend as an example of a potential admin feature.</p>

</div>

<?php get_footer(); ?>