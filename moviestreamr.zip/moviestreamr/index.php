<?php get_header(); ?>

<main>
  <h1>Welcome to MovieStreamr</h1>
  <p>Custom theme is live!</p>
</main>

<?php get_footer(); ?>