document.addEventListener("DOMContentLoaded", () => {
  const overlay = document.getElementById("trailerOverlay");
  const video = document.getElementById("trailerVideo");
  const openBtn = document.querySelector(".launch-trailer");
  const closeBtn = document.getElementById("closeTrailer");
  const watchlistBtn = document.querySelector(".watchlist-toggle");
  const filter = document.getElementById("genreFilter");
  const movieCards = document.querySelectorAll(".movie-card");
  const filterBtn = document.querySelector(".filter-btn");
  const filterToggle = document.getElementById("filterToggle");
  const genreMenu = document.getElementById("genreFilter");
  const genreButtons = document.querySelectorAll(".genre-option");
  const carousel = document.querySelector(".carousel");
  const leftArrow = document.querySelector(".left-arrow");
  const rightArrow = document.querySelector(".right-arrow");
  const deleteForm = document.getElementById("removeMovieForm");
  const confirmDelete = document.getElementById("confirmDelete");
  const addForm = document.getElementById("addMovieForm");
  document
    .querySelector('.filter-dropdown button[data-genre="all"]')
    ?.classList.add("active");

  let selectedGenre = "all";

  // ================================
  // = FILTERING (Home Page)
  // ================================

  if (filter) {
    filter.addEventListener("change", function () {
      const selectedGenre = this.value;

      movieCards.forEach((card) => {
        const genre = card.getAttribute("data-genre");
        if (selectedGenre === "all" || genre === selectedGenre) {
          card.style.display = "";
        } else {
          card.style.display = "none";
        }
      });
    });
  }

  // Toggle the dropdown
  filterBtn?.addEventListener("click", () => {
    const dropdown = document.querySelector(".filter-dropdown");
    dropdown.classList.toggle("hidden");
  });

  // Genre selection handler
  genreMenu?.addEventListener("click", (e) => {
    const target = e.target;
    if (target.matches(".genre-option")) {
      selectedGenre = target.dataset.genre;

      movieCards.forEach((card) => {
        const cardGenre = card.dataset.genre.toLowerCase();

        const isSciFiFantasy =
          selectedGenre === "scifi-fantasy" &&
          (cardGenre === "sci-fi" || cardGenre === "fantasy");

        if (
          selectedGenre === "all" ||
          cardGenre === selectedGenre ||
          isSciFiFantasy
        ) {
          card.style.display = "";
        } else {
          card.style.display = "none";
        }
      });

      genreButtons.forEach((btn) => btn.classList.remove("active-genre"));
      target.classList.add("active-genre");
    }
  });

  // ================================
  // = CAROUSEL SCROLLING (Home) ====
  // ================================

  if (carousel && leftArrow && rightArrow) {
    leftArrow.addEventListener("click", () => {
      carousel.scrollBy({ left: -300, behavior: "smooth" });
    });

    rightArrow.addEventListener("click", () => {
      carousel.scrollBy({ left: 300, behavior: "smooth" });
    });
  }

  // ================================
  // = TRAILER OVERLAY (Single Movie)
  // ================================

  if (overlay && video && openBtn && closeBtn) {
    openBtn.addEventListener("click", () => {
      overlay.style.display = "flex";
      video.currentTime = 0;
      video.play();
    });

    closeBtn.addEventListener("click", () => {
      video.pause();
      overlay.style.display = "none";
    });

    // Optional: close on ESC key
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && overlay.style.display === "flex") {
        video.pause();
        overlay.style.display = "none";
      }
    });
  }

  // ================================
  // = WATCHLIST BUTTON (Single Movie)
  // ================================

  if (watchlistBtn) {
    let watchlist = JSON.parse(localStorage.getItem("watchlist")) || [];
    const movieId = watchlistBtn.dataset.movieId;

    const isInWatchlist = watchlist.includes(movieId);
    watchlistBtn.textContent = isInWatchlist ? "− Watchlist" : "+ Watchlist";

    watchlistBtn.addEventListener("click", () => {
      const index = watchlist.indexOf(movieId);

      if (index > -1) {
        watchlist.splice(index, 1);
        watchlistBtn.textContent = "+ Watchlist";
      } else {
        watchlist.push(movieId);
        watchlistBtn.textContent = "− Watchlist";
      }

      localStorage.setItem("watchlist", JSON.stringify(watchlist));
      console.log(localStorage);
    });
  }

  // ================================
  // = WATCHLIST PAGE RENDERING ====
  // ================================

  if (document.body.classList.contains("page-template-watchlist")) {
    const watchlistContainer = document.getElementById("watchlistContainer");
    const watchlist = JSON.parse(localStorage.getItem("watchlist")) || [];

    if (watchlist.length === 0) {
      watchlistContainer.innerHTML = `
        <div class="empty-watchlist-message">
          <p>Your watchlist is empty.</p>
          <p>When you add movies to your watchlist, they will appear here.</p>
        </div>`;
      return;
    }

    fetch("/wp-json/wp/v2/movie?per_page=100&_embed")
      .then((res) => res.json())
      .then((movies) => {
        const filtered = movies.filter((movie) =>
          watchlist.includes(movie.id.toString())
        );

        filtered.forEach((movie) => {
          const image =
            movie._embedded?.["wp:featuredmedia"]?.[0]?.source_url || "";
          const genre =
            movie._embedded?.["wp:term"]?.[0]?.[0]?.name || "Unknown";

          const movieEl = document.createElement("div");
          movieEl.classList.add("movie-card");
          movieEl.innerHTML = `
  <a href="${movie.link}">
    <img src="${image}" alt="${movie.title.rendered}">
    <h4>${movie.title.rendered}</h4>
    <p>${genre}</p>
  </a>
  <button class="watchlist-remove" data-movie-id="${movie.id}">—</button>
`;
          watchlistContainer.appendChild(movieEl);
          const removeBtn = movieEl.querySelector(".watchlist-remove");
          removeBtn.addEventListener("click", () => {
            const movieId = removeBtn.dataset.movieId;
            const updatedWatchlist = watchlist.filter((id) => id !== movieId);
            localStorage.setItem("watchlist", JSON.stringify(updatedWatchlist));
            movieEl.remove();
          });
        });
      });
  }

  // =============================
  // = ADD MOVIE (Manage Movies Page)
  // =============================

  // This page's backend would be more thorough in a real world development scenario

  if (addForm) {
    addForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const formData = new FormData(addForm);

      try {
        const res = await fetch("/wp-json/wp/v2/movie", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Basic " + btoa("your_username:your_app_password"),
          },
          body: JSON.stringify({
            title: formData.get("title"),
            content: formData.get("description"),
            status: "publish",
            fields: {
              runtime: formData.get("runtime"),
              star_rating: formData.get("star_rating"),
              full_movie: formData.get("full_movie"),
              trailer: formData.get("trailer"),
            },
            genre: formData.get("genre"), // taxonomy assignment
          }),
        });

        const movie = await res.json();
        alert("Movie added: " + movie.title.rendered);
        addForm.reset();
      } catch (err) {
        console.error("Failed to add movie:", err);
        alert("Error adding movie.");
      }
    });
  }

  // =============================
  // = DELETE MOVIE (Manage Movies Page)
  // =============================

  if (deleteForm && confirmDelete) {
    confirmDelete.addEventListener("click", async () => {
      const movieId = document.getElementById("movieToDelete").value;

      if (!movieId) return;

      try {
        const res = await fetch(`/wp-json/wp/v2/movie/${movieId}`, {
          method: "DELETE",
          headers: {
            Authorization: "Basic " + btoa("your_username:your_app_password"),
          },
        });

        const result = await res.json();
        alert(`Deleted movie: ${result.title.rendered}`);
        window.location.reload();
      } catch (err) {
        console.error("Delete failed", err);
        alert("Failed to delete movie.");
      }
    });
  }
});
