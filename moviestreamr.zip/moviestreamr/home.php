<?php
/*
Template Name: Home Page
*/
?>

<?php get_header(); ?>

<?php
$args = array(
    'post_type' => 'movie',
    'posts_per_page' => -1,
);

$movies = get_posts($args);
shuffle($movies); // shuffle ONCE

$first_movie = $movies[0]; // background should match this one
$background_url = get_field('main_image', $first_movie->ID);
?>

<style>
    html,
    body {
        height: 100%;
        margin: 0;
        padding: 0;
    }

    body.home {
        background-image: url('<?php echo esc_url($background_url); ?>');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }
</style>
<section class="home-logo">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/Logo.png" alt="Movie StreamR" />
</section>
<div class="home-content">
    <div class="watchlist-filter">
        <div class="filter-wrapper">

            <button class="go-watchlist" onclick="location.href='/watchlist'">Go to Watchlist</button>
            <div class="filter-div">
                <div id="genreFilter" class="filter-dropdown hidden">
                    <button class="genre-option active-genre" data-genre="all">All</button>
                    <button class="genre-option" data-genre="action">Action</button>
                    <button class="genre-option" data-genre="romance">Romance</button>
                    <button class="genre-option" data-genre="scifi-fantasy">Sci-Fi/Fantasy</button>
                </div>
                <button class="filter-btn">Filter</button>
            </div>
        </div>
    </div>

    <div class="carousel-wrapper">
        <button class="scroll-arrow left-arrow">&#10094;</button>
        <div class="carousel">
            <?php foreach ($movies as $movie): setup_postdata($movie); ?>
                <?php
                $terms = get_the_terms($movie->ID, 'genre');
                $genre_slug = ($terms && !is_wp_error($terms)) ? strtolower($terms[0]->slug) : 'unknown';
                $thumbnail = get_the_post_thumbnail_url($movie->ID, 'medium');
                ?>
                <div class="movie-card" data-genre="<?php echo esc_attr($genre_slug); ?>">
                    <a href="<?php echo get_permalink($movie->ID); ?>">
                        <?php if ($thumbnail): ?>
                            <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr($movie->post_title); ?>">
                        <?php endif; ?>
                        <h4><?php echo esc_html(get_the_title($movie->ID)); ?></h4>
                        <p><?php echo esc_html($terms[0]->name ?? ''); ?></p>
                    </a>
                </div>

            <?php endforeach;
            wp_reset_postdata(); ?>
        </div>
        <button class="scroll-arrow right-arrow">&#10095;</button> <!-- → -->
    </div>
    <a href="/manage-movies" class="manage-link-btn">Manage Movies</a>


</div>

<?php get_footer(); ?>